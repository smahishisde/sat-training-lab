# SAT Training Lab

Student-facing SAT practice portal for GitHub Pages.

## Public content only
This repository should contain only student-facing tests and lessons. Do not upload parent answer keys, student result exports, or private diagnostic notes.

## Structure
- `/math/` — Math tests and targeted lessons
- `/english/` — English tests and targeted lessons
- `/assets/` — shared site styles
